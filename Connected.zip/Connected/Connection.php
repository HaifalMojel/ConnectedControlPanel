<?php
$user = 'root';
$password = 'root';
$db = 'robot';
$host = 'localhost';
$con= mysqli_connect($host,$user,$password,$db);



?>
